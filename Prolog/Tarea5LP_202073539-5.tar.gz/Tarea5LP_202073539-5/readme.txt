Juan Garcia
se apega a lo que se pide en el pdf