import java.io.Reader;
import java.util.*;

public class Main 
{
    public static void main(String[] args) {
        
        String filePath = "ubicacion-tesoro.txt";
        MatrixFileReader reader = new MatrixFileReader(filePath);

        int dim = reader.getDim();
        int aux = reader.getAux();
        int[][] matriz = reader.getMatriz();

        Data thread = new Data(0, reader);
        thread.start();
    }
}